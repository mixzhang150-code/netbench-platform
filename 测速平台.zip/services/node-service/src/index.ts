import express from 'express';
import { createLogger } from '@netbench/logger';
import { NodeInfo, NodeCapabilities } from '@netbench/types';
import { PostgresClient, RedisClient } from '@netbench/database';
import { MessageBus, QUEUES } from '@netbench/messaging';
import { NodeRepository } from './repository';
import { LoadBalancer } from './load-balancer';
import { ReputationSystem } from './reputation';
import { v4 as uuidv4 } from 'uuid';
import jwt from 'jsonwebtoken';

const logger = createLogger('node-service');
const app = express();
app.use(express.json());

const db = new PostgresClient();
const redis = new RedisClient();
const messageBus = new MessageBus();

const nodeRepository = new NodeRepository(db, redis);
const loadBalancer = new LoadBalancer(nodeRepository);
const reputationSystem = new ReputationSystem(nodeRepository);

const JWT_SECRET = process.env.JWT_SECRET || 'jwt_secret_key';

app.get('/health', async (_req, res) => {
  const dbHealthy = await db.healthCheck().catch(() => false);
  const redisHealthy = await redis.healthCheck().catch(() => false);
  const overall = dbHealthy && redisHealthy ? 'healthy' : 'degraded';

  res.json({
    service: 'node-service',
    status: overall,
    uptime: process.uptime(),
    version: '1.0.0',
    dependencies: {
      database: dbHealthy ? 'connected' : 'disconnected',
      redis: redisHealthy ? 'connected' : 'disconnected',
    },
  });
});

app.post('/api/check-name', async (req, res) => {
  try {
    const { name } = req.body;
    if (!name || typeof name !== 'string' || !name.trim()) {
      res.status(400).json({ success: false, error: { code: 'INVALID_NAME', message: '名称不能为空' } });
      return;
    }
    const existing = await nodeRepository.findByName(name.trim());
    res.json({ success: true, available: !existing });
  } catch (error) {
    res.status(500).json({ success: false, error: { code: 'CHECK_ERROR', message: (error as Error).message } });
  }
});

app.post('/api/register', async (req, res) => {
  try {
    const { name, platform, platformDetails, ip, location, capabilities, version } = req.body;

    if (!name || !platform || !ip) {
      res.status(400).json({
        success: false,
        error: { code: 'INVALID_REQUEST', message: 'Name, platform, and IP are required' },
      });
      return;
    }

    const existing = await nodeRepository.findByName(name);
    if (existing) {
      await nodeRepository.updateStatus(existing.id, 'online');
      await nodeRepository.updateHeartbeat(existing.id);
      logger.info('Node re-registered (existing)', { nodeId: existing.id, name });
      res.status(200).json({
        success: true,
        data: {
          id: existing.id,
          token: existing.token,
          status: 'online',
          reRegistered: true,
        },
      });
      return;
    }

    const rawOwnerId = req.headers['x-user-id'] as string;
    const ownerId = rawOwnerId || null;

    const token = jwt.sign(
      { nodeId: '', type: 'node' },
      JWT_SECRET,
      { expiresIn: '365d' }
    );

    const node = await nodeRepository.create({
      name,
      ownerId,
      status: 'online',
      version: version || '1.0.0',
      platform,
      platformDetails: platformDetails || '',
      ip,
      location: location || { country: 'Unknown', region: 'Unknown', city: 'Unknown', lat: 0, lon: 0, isp: 'Unknown' },
      capabilities: capabilities || { ping: true, http: true, speedtest: true, maxConcurrentTasks: 5, bandwidthLimit: 0 },
      token,
    });

    try {
      await messageBus.publish(QUEUES.NODE_EVENTS, {
        type: 'node.registered',
        nodeId: node.id,
        timestamp: new Date().toISOString(),
      });
    } catch (pubError) {
      logger.warn('Failed to publish node.registered event', { error: (pubError as Error).message });
    }

    logger.info('Node registered', { nodeId: node.id, name });

    res.status(201).json({
      success: true,
      data: {
        id: node.id,
        token: node.token,
        status: node.status,
      },
    });
  } catch (error) {
    logger.error('Node registration failed', { error: (error as Error).message });
    res.status(500).json({
      success: false,
      error: { code: 'REGISTRATION_ERROR', message: (error as Error).message },
    });
  }
});

app.post('/api/heartbeat', async (req, res) => {
  try {
    const nodeToken = req.headers['x-node-token'] as string;
    if (!nodeToken) {
      res.status(401).json({
        success: false,
        error: { code: 'UNAUTHORIZED', message: 'Node token required' },
      });
      return;
    }

    const node = await nodeRepository.findByToken(nodeToken);
    if (!node) {
      res.status(401).json({
        success: false,
        error: { code: 'INVALID_TOKEN', message: 'Invalid node token' },
      });
      return;
    }

    const { stats, capabilities } = req.body;

    await nodeRepository.updateHeartbeat(node.id);

    if (node.status !== 'online') {
      await nodeRepository.updateStatus(node.id, 'online');
    }

    if (stats) {
      await nodeRepository.updateStats(node.id, stats);
    }

    try {
      await reputationSystem.recordHeartbeat(node.id, true);
    } catch (repError) {
      logger.warn('Failed to record heartbeat reputation', { nodeId: node.id, error: (repError as Error).message });
    }

    res.json({
      success: true,
      data: {
        nodeId: node.id,
        status: 'online',
        serverTime: new Date().toISOString(),
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: { code: 'HEARTBEAT_ERROR', message: (error as Error).message },
    });
  }
});

app.get('/api/nodes', async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const status = req.query.status as string;

    const result = await nodeRepository.list(page, limit, status);
    res.json({
      success: true,
      data: result.nodes,
      meta: { page, limit, total: result.total },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: { code: 'LIST_ERROR', message: (error as Error).message },
    });
  }
});

app.get('/api/nodes/:id', async (req, res) => {
  try {
    const node = await nodeRepository.findById(req.params.id);
    if (!node) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Node not found' },
      });
      return;
    }
    res.json({ success: true, data: node });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: { code: 'FETCH_ERROR', message: (error as Error).message },
    });
  }
});

app.put('/api/nodes/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    if (!['online', 'offline', 'maintenance'].includes(status)) {
      res.status(400).json({
        success: false,
        error: { code: 'INVALID_STATUS', message: 'Invalid status value' },
      });
      return;
    }

    await nodeRepository.updateStatus(req.params.id, status);
    res.json({ success: true, data: { id: req.params.id, status } });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: { code: 'UPDATE_ERROR', message: (error as Error).message },
    });
  }
});

app.put('/api/nodes/:id', async (req, res) => {
  try {
    const { name, platform, location } = req.body;
    const id = req.params.id;

    const existing = await nodeRepository.findById(id);
    if (!existing) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Node not found' },
      });
      return;
    }

    if (name && name !== existing.name) {
      const nameConflict = await nodeRepository.findByName(name);
      if (nameConflict && nameConflict.id !== id) {
        res.status(409).json({
          success: false,
          error: { code: 'DUPLICATE_NAME', message: `节点名称 "${name}" 已被其他节点使用` },
        });
        return;
      }
    }

    const updates: Record<string, unknown> = {};
    if (name !== undefined) updates.name = name;
    if (platform !== undefined) updates.platform = platform;
    if (location !== undefined) updates.location = JSON.stringify(location || {});

    if (Object.keys(updates).length > 0) {
      const setClauses = Object.keys(updates).map((k, i) => `${k} = $${i + 1}`).join(', ');
      const values = Object.values(updates);
      await db.query(`UPDATE nodes SET ${setClauses}, updated_at = NOW() WHERE id = $${values.length + 1}`, [...values, id]);
    }

    const updated = await nodeRepository.findById(id);
    logger.info('Node updated', { nodeId: id, name: updated?.name });

    res.json({ success: true, data: updated });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: { code: 'UPDATE_ERROR', message: (error as Error).message },
    });
  }
});

app.post('/api/select', async (req, res) => {
  try {
    const { capability, preferredLocation, excludeNodeIds, count } = req.body;

    if (!capability) {
      res.status(400).json({
        success: false,
        error: { code: 'INVALID_REQUEST', message: 'Capability is required' },
      });
      return;
    }

    if (count && count > 1) {
      const nodes = await loadBalancer.selectMultipleNodes(
        capability,
        preferredLocation,
        excludeNodeIds || [],
      );
      res.json({ success: true, data: nodes });
    } else {
      const node = await loadBalancer.selectNode(
        capability,
        preferredLocation,
        excludeNodeIds || [],
      );
      res.json({ success: true, data: node });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: { code: 'SELECT_ERROR', message: (error as Error).message },
    });
  }
});

app.post('/api/:id/evaluate', async (req, res) => {
  try {
    const reputation = await reputationSystem.evaluateNode(req.params.id);
    res.json({ success: true, data: reputation });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: { code: 'EVALUATION_ERROR', message: (error as Error).message },
    });
  }
});

app.post('/api/:id/task-result', async (req, res) => {
  try {
    const body = req.body as { success?: boolean; responseTime?: number; taskId?: string; type?: string; target?: string; status?: string; result?: unknown };
    await reputationSystem.recordTaskResult(req.params.id, body.success ?? false, body.responseTime ?? 0);
    if (body.taskId) {
      await redis.set('task-result:' + body.taskId, JSON.stringify({
        nodeId: req.params.id,
        type: body.type,
        target: body.target,
        status: body.status,
        result: body.result,
        completedAt: new Date().toISOString(),
      }), 7200);
    }
    logger.info('Task result received', { nodeId: req.params.id, taskId: body.taskId });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: { code: 'RECORD_ERROR', message: (error as Error).message } });
  }
});

app.post('/api/nodes/push-task', async (req, res) => {
  try {
    const body = req.body as { nodeId?: string; taskId?: string; type?: string; target?: string; config?: Record<string, unknown> };
    if (!body.nodeId || !body.taskId) {
      res.status(400).json({ success: false, error: { code: 'INVALID', message: 'Missing fields' } });
      return;
    }
    const node = await nodeRepository.findById(body.nodeId);
    if (!node) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Node not found' } });
      return;
    }
    const taskData = JSON.stringify({
      taskId: body.taskId,
      type: body.type,
      target: body.target,
      config: body.config || {},
      pushedAt: new Date().toISOString(),
    });
    await redis.lpush('tasks:' + body.nodeId, taskData);
    await redis.expire('tasks:' + body.nodeId, 3600);
    logger.info('Task pushed to node', { nodeId: body.nodeId, taskId: body.taskId });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: { code: 'PUSH_ERROR', message: (error as Error).message } });
  }
});

app.get('/api/tasks/:taskId/result', async (req, res) => {
  try {
    const raw = await redis.get('task-result:' + req.params.taskId);
    if (!raw) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Result not found' } });
      return;
    }
    res.json({ success: true, data: JSON.parse(raw) });
  } catch (error) {
    res.status(500).json({ success: false, error: { code: 'RESULT_ERROR', message: (error as Error).message } });
  }
});

app.get('/api/:id/tasks', async (req, res) => {
  try {
    const node = await nodeRepository.findById(req.params.id);
    if (!node) { res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Node not found' } }); return; }
    const tasks = [];
    while (true) {
      const raw = await redis.rpop(`tasks:${req.params.id}`);
      if (!raw) break;
      try { tasks.push(JSON.parse(raw)); } catch { continue; }
    }
    res.json({ success: true, data: tasks });
  } catch (error) {
    res.status(500).json({ success: false, error: { code: 'TASK_ERROR', message: (error as Error).message } });
  }
});

app.delete('/api/nodes/:id', async (req, res) => {
  try {
    await nodeRepository.delete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: { code: 'DELETE_ERROR', message: (error as Error).message },
    });
  }
});

const PORT = process.env.PORT || 3004;

async function main() {
  try {
    await messageBus.connect();
  } catch (error) {
    logger.warn('Failed to connect to RabbitMQ, running without message bus', { error: (error as Error).message });
  }

  app.listen(PORT, () => {
    logger.info(`Node service running on port ${PORT}`);
  });

  setInterval(async () => {
    if (!messageBus.isConnected()) {
      try {
        await messageBus.connect();
        logger.info('Reconnected to RabbitMQ');
      } catch {
        logger.warn('RabbitMQ reconnection failed');
      }
    }
  }, 30000);

  setInterval(async () => {
    try {
      const { nodes } = await nodeRepository.list(1, 1000, 'online');
      const now = Date.now();
      for (const node of nodes) {
        const lastHeartbeat = new Date(node.lastHeartbeat).getTime();
        if (now - lastHeartbeat > 90000) {
          logger.warn('Node heartbeat timeout, marking offline', { nodeId: node.id });
          await nodeRepository.updateStatus(node.id, 'offline');
        }
      }
    } catch (error) {
      logger.error('Heartbeat check failed', { error: (error as Error).message });
    }
  }, 60000);
}

main().catch((error) => {
  logger.error('Failed to start node service', { error: error.message });
  process.exit(1);
});

process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down');
  await messageBus.disconnect();
  await redis.close();
  await db.close();
  process.exit(0);
});
