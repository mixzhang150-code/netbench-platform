import { useState, useEffect } from 'react';
import { dataApi } from '../api';
import {
  Box, Typography, Card, CardContent, TextField, MenuItem,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Chip, Button, LinearProgress,
} from '@mui/material';

export function History() {
  const [results, setResults] = useState<unknown[]>([]);
  const [loading, setLoading] = useState(true);
  const [type, setType] = useState('');
  const [page, setPage] = useState(1);

  useEffect(() => { loadHistory(); }, [type, page]);

  const loadHistory = async () => {
    try { const response = await dataApi.history({ type: type || undefined, page, limit: 20 }); setResults(response.data.data || []); } catch {} finally { setLoading(false); }
  };

  const getTypeLabel = (t: string) => { switch (t) { case 'ping': return 'Ping'; case 'http': return 'HTTP'; case 'speedtest': return '测速'; default: return t; } };

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" fontWeight={700}>历史记录</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>查看所有测试历史数据</Typography>
      </Box>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <TextField select size="small" label="类型" value={type} onChange={(e) => { setType(e.target.value); setPage(1); }} sx={{ width: 160 }}>
            <MenuItem value="">全部类型</MenuItem>
            <MenuItem value="ping">Ping</MenuItem>
            <MenuItem value="http">HTTP</MenuItem>
            <MenuItem value="speedtest">测速</MenuItem>
          </TextField>
        </CardContent>
      </Card>

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 6 }}><LinearProgress sx={{ maxWidth: 200, mx: 'auto' }} /></Box>
      ) : (
        <Card>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>类型</TableCell><TableCell>目标</TableCell><TableCell>状态</TableCell><TableCell>节点</TableCell><TableCell>时间</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {(results as Record<string, unknown>[]).map((row, i) => (
                  <TableRow key={i}>
                    <TableCell>{getTypeLabel(row.type as string)}</TableCell>
                    <TableCell>{row.target as string}</TableCell>
                    <TableCell><Chip label={row.status as string} size="small" color={row.status === 'success' ? 'success' : 'error'} /></TableCell>
                    <TableCell>{row.node_location as string}</TableCell>
                    <TableCell><Typography variant="body2" color="text.secondary">{new Date(row.created_at as string).toLocaleString('zh-CN')}</Typography></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 2, py: 2 }}>
            <Button size="small" disabled={page === 1} onClick={() => setPage(p => Math.max(1, p - 1))}>上一页</Button>
            <Typography variant="body2" color="text.secondary">第 {page} 页</Typography>
            <Button size="small" onClick={() => setPage(p => p + 1)}>下一页</Button>
          </Box>
        </Card>
      )}
    </Box>
  );
}
