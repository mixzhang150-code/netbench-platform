import { useState, useEffect } from 'react';
import { nodeApi, testApi } from '../api';
import { useNavigate } from 'react-router-dom';
import {
  Box, Typography, Card, CardContent, Grid, TextField, Button,
  Paper, Chip,
} from '@mui/material';
import WifiTetheringIcon from '@mui/icons-material/WifiTethering';
import LanguageIcon from '@mui/icons-material/Language';
import SpeedIcon from '@mui/icons-material/Speed';
import DownloadIcon from '@mui/icons-material/Download';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import PublicIcon from '@mui/icons-material/Public';
import DnsIcon from '@mui/icons-material/Dns';
import SecurityIcon from '@mui/icons-material/Security';
import BarChartIcon from '@mui/icons-material/BarChart';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';

export function Dashboard() {
  const [stats, setStats] = useState({ totalNodes: 0, onlineNodes: 0, totalTests: 0, avgLatency: 0 });
  const [quickTarget, setQuickTarget] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadStats();
    const interval = setInterval(loadStats, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadStats = async () => {
    try {
      const [nodesRes, onlineRes, statsRes] = await Promise.all([
        nodeApi.list(1, 1),
        nodeApi.list(1, 1, 'online'),
        testApi.stats().catch(() => ({ data: { data: { totalTests: 0, todayTests: 0, avgLatency: 0 } } })),
      ]);
      setStats({
        totalNodes: nodesRes.data.meta?.total || 0,
        onlineNodes: onlineRes.data.meta?.total || 0,
        totalTests: statsRes.data.data?.todayTests || 0,
        avgLatency: statsRes.data.data?.avgLatency || 0,
      });
    } catch {} finally { setLoading(false); }
  };

  const handleQuickTest = (type: string) => {
    if (!quickTarget.trim()) return;
    if (type === 'ping') navigate(`/ping?target=${encodeURIComponent(quickTarget)}`);
    else navigate(`/http?url=${encodeURIComponent(quickTarget)}`);
  };

  const statCards = [
    { label: '总节点数', value: stats.totalNodes, color: 'primary' as const },
    { label: '在线节点', value: stats.onlineNodes, color: 'success' as const },
    { label: '今日测试', value: stats.totalTests, color: 'info' as const },
    { label: '平均延迟', value: `${stats.avgLatency}ms`, color: 'secondary' as const },
  ];

  const features = [
    { icon: <PublicIcon color="info" />, title: '多点并发测试', desc: '输入一个目标，从全球所有在线节点同时发起测试，实时查看各地网络状况', color: 'info' },
    { icon: <DnsIcon color="success" />, title: '节点赞助', desc: '安装节点程序即可贡献测试节点，获得信誉积分，帮助社区建设全球测试网络', color: 'success' },
    { icon: <BarChartIcon color="secondary" />, title: '实时结果', desc: 'WebSocket实时推送各节点测试结果，按延迟/速度自动排序，颜色标识状态', color: 'secondary' },
    { icon: <SecurityIcon color="warning" />, title: '安全可靠', desc: '节点通信加密、信誉积分系统、自动故障转移，确保测试结果准确可信', color: 'warning' },
  ];

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" fontWeight={700}>仪表盘</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>NetBench 网络多点测试平台</Typography>
      </Box>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        {statCards.map((s) => (
          <Grid item xs={6} md={3} key={s.label}>
            <Card>
              <CardContent sx={{ textAlign: 'center', py: 3 }}>
                <Typography variant="h4" fontWeight={700} color={`${s.color}.main`}>{s.value}</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>{s.label}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Card sx={{ mb: 4 }}>
        <CardContent>
          <Typography variant="h6" fontWeight={600} sx={{ mb: 1 }}>快速测试</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            输入域名或IP，从全球多个节点同时测试网络连通性
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, gap: 1.5, alignItems: { sm: 'flex-end' } }}>
            <TextField
              size="small" placeholder="输入域名或IP，如: baidu.com" value={quickTarget}
              onChange={(e) => setQuickTarget(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleQuickTest('ping')}
              sx={{ flex: 1, minWidth: 0 }}
            />
            <Box sx={{ display: 'flex', gap: 1, width: { xs: '100%', sm: 'auto' } }}>
              <Button variant="contained" startIcon={<WifiTetheringIcon />} disabled={!quickTarget.trim()} onClick={() => handleQuickTest('ping')} fullWidth>
                Ping 测试
              </Button>
              <Button variant="contained" startIcon={<LanguageIcon />} disabled={!quickTarget.trim()} onClick={() => handleQuickTest('http')} fullWidth>
                HTTP 测试
              </Button>
            </Box>
          </Box>
        </CardContent>
      </Card>

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>测试工具</Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                {[
                  { icon: <WifiTetheringIcon color="primary" />, title: 'Ping 多点测试', desc: '从多个节点同时Ping，检测各地连通性', path: '/ping' },
                  { icon: <LanguageIcon color="primary" />, title: 'HTTP 多点测试', desc: '多节点HTTP请求，检测各地响应状态', path: '/http' },
                  { icon: <SpeedIcon color="primary" />, title: '网络多点测速', desc: '多节点下载/上传速度和延迟测试', path: '/speedtest' },
                ].map((tool) => (
                  <Paper key={tool.path} variant="outlined" sx={{ p: 2, cursor: 'pointer', '&:hover': { borderColor: 'primary.light', bgcolor: 'primary.50' } }} onClick={() => navigate(tool.path)}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      {tool.icon}
                      <Box>
                        <Typography variant="body2" fontWeight={600}>{tool.title}</Typography>
                        <Typography variant="caption" color="text.secondary">{tool.desc}</Typography>
                      </Box>
                    </Box>
                  </Paper>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>平台特性</Typography>
              <Grid container spacing={2}>
                {features.map((f) => (
                  <Grid item xs={12} sm={6} key={f.title}>
                    <Paper sx={{ p: 2, bgcolor: `${f.color}.50` }} elevation={0}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                        {f.icon}
                        <Typography variant="body2" fontWeight={600} color={`${f.color}.main`}>{f.title}</Typography>
                      </Box>
                      <Typography variant="caption" color="text.secondary">{f.desc}</Typography>
                    </Paper>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Card
        onClick={() => navigate('/sponsor')}
        sx={{
          cursor: 'pointer',
          background: (t) => `linear-gradient(135deg, ${t.palette.primary.main} 0%, ${t.palette.secondary.main} 100%)`,
          color: '#fff',
          '&:hover': { boxShadow: 8 },
        }}
      >
        <CardContent sx={{ display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, alignItems: 'center', gap: 2, py: 3 }}>
          <DownloadIcon sx={{ fontSize: 48, opacity: 0.9 }} />
          <Box>
            <Typography variant="h6" fontWeight={700}>想贡献一个测试节点？</Typography>
            <Typography variant="body2" sx={{ opacity: 0.85 }}>
              一条命令即可部署，帮助扩大全球网络测试覆盖范围
            </Typography>
            <Button endIcon={<ArrowForwardIcon />} sx={{ mt: 1, color: '#fff', borderColor: 'rgba(255,255,255,0.5)' }} variant="outlined" size="small">
              查看安装指南
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
