import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/auth';
import { nodeApi, userApi, monitorApi } from '../api';
import {
  Box, Typography, Card, CardContent, Grid, Chip,
  LinearProgress, Button, Paper,
} from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';
import DnsIcon from '@mui/icons-material/Dns';
import MonitorHeartIcon from '@mui/icons-material/MonitorHeart';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import WarningIcon from '@mui/icons-material/Warning';
import DownloadIcon from '@mui/icons-material/Download';

interface ServiceHealth {
  service: string;
  status: string;
  uptime?: number;
  dependencies?: Record<string, string>;
}

export function Admin() {
  const navigate = useNavigate();
  const { user } = useAuthStore();

  const [stats, setStats] = useState({
    totalNodes: 0, onlineNodes: 0, offlineNodes: 0,
    totalUsers: 0, adminUsers: 0,
  });
  const [services, setServices] = useState<ServiceHealth[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadAll(); const t = setInterval(loadAll, 60000); return () => clearInterval(t); }, []);

  const loadAll = async () => {
    try {
      const [nodesRes, onlineRes, usersRes, monRes] = await Promise.allSettled([
        nodeApi.list(1, 1),
        nodeApi.list(1, 1000),
        userApi.list(1, 1000),
        monitorApi.health(),
      ]);

      const totalNodes = nodesRes.status === 'fulfilled' ? (nodesRes.value.data.meta?.total || 0) : 0;
      const nodeData = onlineRes.status === 'fulfilled' ? (onlineRes.value.data.data || []) : [];
      const onlineNodes = nodeData.filter((n: { status: string }) => n.status === 'online').length;
      const userData = usersRes.status === 'fulfilled' ? (usersRes.value.data.data || []) : [];

      setStats({
        totalNodes,
        onlineNodes,
        offlineNodes: totalNodes - onlineNodes,
        totalUsers: userData.length,
        adminUsers: userData.filter((u: { role: string }) => u.role === 'admin').length,
      });

      if (monRes.status === 'fulfilled') {
        setServices(monRes.value.data.services || []);
      }
    } catch {} finally { setLoading(false); }
  };

  const getStatusColor = (status: string) => {
    if (status === 'healthy') return '#2e7d32';
    if (status === 'degraded') return '#ed6c02';
    return '#d32f2f';
  };
  const getStatusLabel = (s: string) => s === 'healthy' ? '正常' : s === 'degraded' ? '降级' : '异常';

  const quickActions = [
    { icon: <DnsIcon color="success" sx={{ fontSize: 32 }} />, title: '节点管理', desc: `${stats.onlineNodes}/${stats.totalNodes} 在线`, path: '/admin/nodes', color: 'success' },
    { icon: <PeopleIcon color="primary" sx={{ fontSize: 32 }} />, title: '用户管理', desc: `${stats.adminUsers} 管理员 / ${stats.totalUsers} 用户`, path: '/admin/users', color: 'primary' },
    { icon: <MonitorHeartIcon color="info" sx={{ fontSize: 32 }} />, title: '系统监控', desc: `${services.filter(s => s.status === 'healthy').length}/${services.length} 服务正常`, path: undefined, color: 'info' },
    { icon: <DownloadIcon color="secondary" sx={{ fontSize: 32 }} />, title: '节点赞助页面', desc: '公开的安装指南和脚本', path: '/sponsor', color: 'secondary' },
  ];

  return (
    <Box>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box>
          <Typography variant="h5" fontWeight={700}>后台管理</Typography>
          <Typography variant="body2" color="text.secondary">欢迎, {user?.username}</Typography>
        </Box>
        <Button size="small" onClick={loadAll} disabled={loading}>刷新</Button>
      </Box>

      {/* 统计卡片 */}
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {[
          { label: '总节点数', value: stats.totalNodes, sub: `离线 ${stats.offlineNodes}`, color: 'text.primary' },
          { label: '在线节点', value: stats.onlineNodes, sub: '', color: 'success.main' },
          { label: '总用户数', value: stats.totalUsers, sub: `管理员 ${stats.adminUsers}`, color: 'text.primary' },
          { label: '服务状态', value: `${services.filter(s => s.status === 'healthy').length}/${services.length}`, sub: '正常', color: services.some(s => s.status !== 'healthy') ? 'warning.main' : 'success.main' },
        ].map((s) => (
          <Grid item xs={6} md={3} key={s.label}>
            <Card>
              <CardContent sx={{ textAlign: 'center', py: 2.5 }}>
                <Typography variant="h4" fontWeight={700} color={s.color}>{loading ? '-' : s.value}</Typography>
                <Typography variant="body2" color="text.secondary">{s.label}</Typography>
                {s.sub && <Typography variant="caption" color="text.disabled">{s.sub}</Typography>}
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* 快捷操作 */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {quickActions.map((a) => (
          <Grid item xs={12} sm={6} md={3} key={a.title}>
            <Card
              sx={{ cursor: a.path ? 'pointer' : 'default', '&:hover': a.path ? { boxShadow: 6 } : {}, borderLeft: `4px solid`, borderColor: `${a.color}.main` }}
              onClick={() => a.path && navigate(a.path)}
            >
              <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 2, py: 2 }}>
                {a.icon}
                <Box>
                  <Typography variant="subtitle1" fontWeight={600}>{a.title}</Typography>
                  <Typography variant="body2" color="text.secondary">{a.desc}</Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* 服务健康状态 */}
      <Card>
        <CardContent>
          <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>服务健康状态</Typography>
          {loading ? (
            <LinearProgress />
          ) : services.length > 0 ? (
            <Grid container spacing={2}>
              {services.map((svc) => (
                <Grid item xs={12} sm={6} md={4} key={svc.service}>
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                      {svc.status === 'healthy'
                        ? <CheckCircleIcon sx={{ color: getStatusColor(svc.status), fontSize: 20 }} />
                        : svc.status === 'degraded'
                          ? <WarningIcon sx={{ color: getStatusColor(svc.status), fontSize: 20 }} />
                          : <ErrorIcon sx={{ color: getStatusColor(svc.status), fontSize: 20 }} />}
                      <Typography variant="body2" fontWeight={600}>{svc.service}</Typography>
                      <Chip label={getStatusLabel(svc.status)} size="small"
                        color={svc.status === 'healthy' ? 'success' : svc.status === 'degraded' ? 'warning' : 'error'}
                        sx={{ ml: 'auto', height: 22, fontSize: 12 }} />
                    </Box>
                    {svc.uptime !== undefined && (
                      <Typography variant="caption" color="text.secondary">
                        运行时间: {Math.floor(svc.uptime / 3600)}h{Math.floor((svc.uptime % 3600) / 60)}m
                      </Typography>
                    )}
                    {svc.dependencies && Object.entries(svc.dependencies).map(([k, v]) => (
                      <Box key={k} sx={{ display: 'flex', gap: 1, mt: 0.5 }}>
                        <Typography variant="caption" color="text.disabled">{k}:</Typography>
                        <Typography variant="caption" color={v === 'connected' ? 'success.main' : 'error.main'}>{v}</Typography>
                      </Box>
                    ))}
                  </Paper>
                </Grid>
              ))}
            </Grid>
          ) : (
            <Typography color="text.secondary" sx={{ textAlign: 'center', py: 3 }}>暂无服务监控数据</Typography>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}

