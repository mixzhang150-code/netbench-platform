import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/auth';
import { nodeApi } from '../api';
import {
  Box, Typography, Card, CardContent, Grid, TextField, Chip,
  LinearProgress, Button, Dialog, DialogTitle, DialogContent,
  DialogActions, IconButton, Snackbar, Alert, Tooltip,
  Select, MenuItem, FormControl, InputLabel,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import CloseIcon from '@mui/icons-material/Close';

interface NodeData {
  id: string; name: string; status: string; platform: string;
  location: { country: string; city: string; isp: string };
  reputation: { score: number; totalTasks: number; uptime: number };
  capabilities: { ping: boolean; http: boolean; speedtest: boolean };
  lastHeartbeat: string;
}

export function Nodes() {
  const navigate = useNavigate();
  const { user } = useAuthStore();

  if (user?.role !== 'admin') {
    return (
      <Box sx={{ textAlign: 'center', py: 8 }}>
        <Typography variant="h6" color="text.secondary">无权限访问</Typography>
        <Button sx={{ mt: 2 }} onClick={() => navigate('/admin')}>返回后台管理</Button>
      </Box>
    );
  }

  const [nodes, setNodes] = useState<NodeData[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' as 'success' | 'error' });

  // 删除
  const [deleteTarget, setDeleteTarget] = useState<NodeData | null>(null);
  const [deleting, setDeleting] = useState(false);

  // 编辑
  const [editTarget, setEditTarget] = useState<NodeData | null>(null);
  const [editForm, setEditForm] = useState({ name: '', city: '', isp: '', platform: '' });
  const [editLoading, setEditLoading] = useState(false);

  // 注册
  const [registerOpen, setRegisterOpen] = useState(false);
  const [registerForm, setRegisterForm] = useState({ name: '', platform: 'linux', ip: '', city: '', isp: '' });
  const [registerLoading, setRegisterLoading] = useState(false);
  const [nameError, setNameError] = useState('');
  const [nameChecking, setNameChecking] = useState(false);

  useEffect(() => { loadNodes(); const interval = setInterval(loadNodes, 30000); return () => clearInterval(interval); }, []);

  const loadNodes = async () => {
    try { const response = await nodeApi.list(1, 100); setNodes(response.data.data || []); } catch {} finally { setLoading(false); }
  };

  const handleDelete = useCallback(async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await nodeApi.delete(deleteTarget.id);
      setSnackbar({ open: true, message: `节点 "${deleteTarget.name}" 已删除`, severity: 'success' });
      setDeleteTarget(null);
      loadNodes();
    } catch {
      setSnackbar({ open: true, message: '删除失败，请重试', severity: 'error' });
    } finally {
      setDeleting(false);
    }
  }, [deleteTarget]);

  const handleEditOpen = (node: NodeData) => {
    setEditTarget(node);
    setEditForm({
      name: node.name,
      city: node.location?.city || '',
      isp: node.location?.isp || '',
      platform: node.platform || 'linux',
    });
  };

  const handleEditSave = async () => {
    if (!editTarget) return;
    if (!editForm.name.trim()) return;

    setEditLoading(true);
    try {
      await nodeApi.update(editTarget.id, {
        name: editForm.name.trim(),
        platform: editForm.platform,
        location: {
          country: editTarget.location?.country || 'CN',
          city: editForm.city,
          isp: editForm.isp,
          lat: 0, lon: 0,
        },
      });
      setSnackbar({ open: true, message: `节点 "${editForm.name}" 已更新`, severity: 'success' });
      setEditTarget(null);
      loadNodes();
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error?.message || '更新失败';
      setSnackbar({ open: true, message: msg, severity: 'error' });
    } finally {
      setEditLoading(false);
    }
  };

  const checkNameUnique = async (name: string, excludeId?: string) => {
    if (!name.trim()) return;
    setNameChecking(true);
    try {
      const res = await nodeApi.checkName(name.trim());
      if (!res.data.success || !res.data.available) {
        setNameError('节点名称已存在，请使用其他名称');
      } else {
        setNameError('');
      }
    } catch { setNameError(''); }
    setNameChecking(false);
  };

  const handleNameChange = (value: string) => {
    setRegisterForm(prev => ({ ...prev, name: value }));
    setNameError('');
  };

  const handleRegister = async () => {
    if (!registerForm.name.trim()) { setNameError('节点名称不能为空'); return; }
    if (nameError) return;

    setRegisterLoading(true);
    try {
      await nodeApi.register({
        name: registerForm.name.trim(),
        platform: registerForm.platform,
        ip: registerForm.ip || undefined,
        location: {
          country: 'CN',
          city: registerForm.city || '',
          isp: registerForm.isp || '',
          lat: 0, lon: 0,
        },
      });
      setSnackbar({ open: true, message: `节点 "${registerForm.name}" 注册成功`, severity: 'success' });
      setRegisterOpen(false);
      setRegisterForm({ name: '', platform: 'linux', ip: '', city: '', isp: '' });
      loadNodes();
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error?.message || '注册失败';
      setSnackbar({ open: true, message: msg, severity: 'error' });
    } finally {
      setRegisterLoading(false);
    }
  };

  const filteredNodes = nodes.filter(node =>
    node.name.toLowerCase().includes(filter.toLowerCase()) ||
    node.location?.city?.toLowerCase().includes(filter.toLowerCase())
  );

  const getStatusChip = (status: string) => {
    switch (status) {
      case 'online': return <Chip label="在线" size="small" color="success" />;
      case 'offline': return <Chip label="离线" size="small" color="error" />;
      case 'maintenance': return <Chip label="维护中" size="small" color="warning" />;
      default: return <Chip label={status} size="small" />;
    }
  };

  const getReputationColor = (score: number) => { if (score >= 80) return '#2e7d32'; if (score >= 50) return '#ed6c02'; return '#d32f2f'; };

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" fontWeight={700}>节点管理</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>查看、编辑、注册和删除测试节点</Typography>
      </Box>

      <Card sx={{ mb: 3 }}>
        <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
          <TextField
            size="small"
            placeholder="搜索节点名称或城市..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            sx={{ maxWidth: 400, flexGrow: 1 }}
            InputProps={{ startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} /> }}
          />
          <Button variant="contained" startIcon={<AddIcon />} onClick={() => setRegisterOpen(true)}>
            注册节点
          </Button>
        </CardContent>
      </Card>

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 6 }}><LinearProgress sx={{ maxWidth: 200, mx: 'auto' }} /></Box>
      ) : (
        <Grid container spacing={2}>
          {filteredNodes.map((node) => (
            <Grid item xs={12} sm={6} md={4} key={node.id}>
              <Card sx={{ position: 'relative' }}>
                <Box sx={{ position: 'absolute', top: 8, right: 8, display: 'flex', gap: 0.5 }}>
                  <Tooltip title="编辑">
                    <IconButton size="small" onClick={() => handleEditOpen(node)} sx={{ color: 'text.secondary' }}>
                      <EditIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="删除">
                    <IconButton size="small" onClick={() => setDeleteTarget(node)} sx={{ color: 'text.secondary' }}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Box>
                <CardContent sx={{ pr: 7 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight={600}>{node.name}</Typography>
                    {getStatusChip(node.status)}
                  </Box>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}><Typography variant="body2" color="text.secondary">平台</Typography><Typography variant="body2" fontWeight={500}>{node.platform}</Typography></Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}><Typography variant="body2" color="text.secondary">位置</Typography><Typography variant="body2" fontWeight={500}>{node.location?.city}, {node.location?.country}</Typography></Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}><Typography variant="body2" color="text.secondary">ISP</Typography><Typography variant="body2" fontWeight={500}>{node.location?.isp}</Typography></Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}><Typography variant="body2" color="text.secondary">信誉积分</Typography><Typography variant="body2" fontWeight={700} sx={{ color: getReputationColor(node.reputation?.score || 0) }}>{node.reputation?.score || 0}</Typography></Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}><Typography variant="body2" color="text.secondary">可用率</Typography><Typography variant="body2" fontWeight={500}>{node.reputation?.uptime?.toFixed(1) || 0}%</Typography></Box>
                  </Box>
                  <Box sx={{ mt: 1.5, display: 'flex', gap: 0.5 }}>
                    {node.capabilities?.ping && <Chip label="Ping" size="small" variant="outlined" color="primary" />}
                    {node.capabilities?.http && <Chip label="HTTP" size="small" variant="outlined" color="success" />}
                    {node.capabilities?.speedtest && <Chip label="Speed" size="small" variant="outlined" color="secondary" />}
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
          {filteredNodes.length === 0 && (
            <Grid item xs={12}><Card><CardContent sx={{ textAlign: 'center', py: 6 }}><Typography color="text.secondary">暂无节点数据</Typography></CardContent></Card></Grid>
          )}
        </Grid>
      )}

      {/* 编辑节点对话框 */}
      <Dialog open={!!editTarget} onClose={() => setEditTarget(null)} maxWidth="sm" fullWidth>
        <DialogTitle>编辑节点 - {editTarget?.name}</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
            <TextField
              label="节点名称 *"
              value={editForm.name}
              onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
              required
              fullWidth
            />
            <Box sx={{ display: 'flex', gap: 2 }}>
              <FormControl sx={{ flex: 1 }}>
                <InputLabel>平台</InputLabel>
                <Select
                  value={editForm.platform}
                  label="平台"
                  onChange={(e) => setEditForm(prev => ({ ...prev, platform: e.target.value }))}
                >
                  <MenuItem value="linux">Linux</MenuItem>
                  <MenuItem value="windows">Windows</MenuItem>
                  <MenuItem value="macOS">macOS</MenuItem>
                </Select>
              </FormControl>
              <TextField
                label="ISP/运营商"
                value={editForm.isp}
                onChange={(e) => setEditForm(prev => ({ ...prev, isp: e.target.value }))}
                placeholder="如：中国电信"
                sx={{ flex: 1 }}
              />
            </Box>
            <TextField
              label="城市"
              value={editForm.city}
              onChange={(e) => setEditForm(prev => ({ ...prev, city: e.target.value }))}
              placeholder="如：北京"
              fullWidth
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditTarget(null)}>取消</Button>
          <Button variant="contained" onClick={handleEditSave} disabled={editLoading || !editForm.name.trim()}>
            {editLoading ? '保存中...' : '保存'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* 删除确认对话框 */}
      <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} maxWidth="xs" fullWidth>
        <DialogTitle>确认删除节点</DialogTitle>
        <DialogContent>
          <Typography>确定要删除节点 <strong>{deleteTarget?.name}</strong> 吗？此操作不可撤销。</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteTarget(null)}>取消</Button>
          <Button variant="contained" color="error" onClick={handleDelete} disabled={deleting}>
            {deleting ? '删除中...' : '确认删除'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* 注册节点对话框 */}
      <Dialog open={registerOpen} onClose={() => { setRegisterOpen(false); setNameError(''); }} maxWidth="sm" fullWidth>
        <DialogTitle>注册新节点</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}>
            <TextField
              label="节点名称 *"
              value={registerForm.name}
              onChange={(e) => handleNameChange(e.target.value)}
              onBlur={(e) => e.target.value.trim() && checkNameUnique(e.target.value)}
              error={!!nameError}
              helperText={nameError || (nameChecking ? '正在检查名称唯一性...' : '')}
              required
              fullWidth
            />
            <TextField
              label="IP 地址"
              value={registerForm.ip}
              onChange={(e) => setRegisterForm(prev => ({ ...prev, ip: e.target.value }))}
              placeholder="留空则自动检测"
              fullWidth
            />
            <Box sx={{ display: 'flex', gap: 2 }}>
              <TextField
                label="平台"
                select
                value={registerForm.platform}
                onChange={(e) => setRegisterForm(prev => ({ ...prev, platform: e.target.value }))}
                sx={{ flex: 1 }}
                SelectProps={{ native: true }}
              >
                <option value="linux">Linux</option>
                <option value="windows">Windows</option>
                <option value="macOS">macOS</option>
              </TextField>
              <TextField
                label="ISP/运营商"
                value={registerForm.isp}
                onChange={(e) => setRegisterForm(prev => ({ ...prev, isp: e.target.value }))}
                placeholder="如：中国电信"
                sx={{ flex: 1 }}
              />
            </Box>
            <TextField
              label="城市"
              value={registerForm.city}
              onChange={(e) => setRegisterForm(prev => ({ ...prev, city: e.target.value }))}
              placeholder="如：北京"
              fullWidth
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setRegisterOpen(false); setNameError(''); }}>取消</Button>
          <Button variant="contained" onClick={handleRegister} disabled={registerLoading || !!nameError || !registerForm.name.trim()}>
            {registerLoading ? '注册中...' : '确认注册'}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar(prev => ({ ...prev, open: false }))}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert severity={snackbar.severity} variant="filled" onClose={() => setSnackbar(prev => ({ ...prev, open: false }))} icon={<CloseIcon fontSize="small" />}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
