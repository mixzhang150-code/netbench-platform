import { useState, useEffect, useRef, useCallback } from 'react';
import { testApi, createTestWebSocket, NodeTestResult } from '../api';
import {
  Box, Typography, Card, CardContent, Grid, TextField, Button,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Chip, LinearProgress, Alert, Paper, useMediaQuery, useTheme,
} from '@mui/material';
import WifiTetheringIcon from '@mui/icons-material/WifiTethering';

export function PingTest() {
  const [target, setTarget] = useState('');
  const [count, setCount] = useState(4);
  const [timeout, setTimeout_] = useState(5000);
  const [loading, setLoading] = useState(false);
  const [batchId, setBatchId] = useState<string | null>(null);
  const [results, setResults] = useState<Map<string, NodeTestResult>>(new Map());
  const [totalNodes, setTotalNodes] = useState(0);
  const [error, setError] = useState('');
  const wsRef = useRef<WebSocket | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const handleResult = useCallback((taskResult: NodeTestResult) => {
    setResults(prev => { const next = new Map(prev); next.set(taskResult.taskId, taskResult); return next; });
  }, []);

  useEffect(() => { return () => { wsRef.current?.close(); if (pollRef.current) clearInterval(pollRef.current); }; }, []);

  const startPolling = (id: string) => {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const res = await testApi.getBatch(id);
        if (res.data.success && res.data.data) {
          const batch = res.data.data;
          for (const task of batch.tasks) handleResult(task);
          if (['completed', 'partial', 'failed'].includes(batch.status)) { if (pollRef.current) clearInterval(pollRef.current); setLoading(false); }
        }
      } catch {}
    }, 2000);
  };

  const handleTest = async () => {
    if (!target.trim()) { setError('请输入目标主机'); return; }
    setLoading(true); setError(''); setResults(new Map()); setBatchId(null);
    try {
      const response = await testApi.ping({ target: target.trim(), count, timeout, maxNodes: 50 });
      if (response.data.success && response.data.data) {
        const batch = response.data.data;
        setBatchId(batch.batchId); setTotalNodes(batch.totalNodes);
        try { wsRef.current?.close(); wsRef.current = createTestWebSocket((msg) => { if (msg.type === 'test:result' && msg.data) { const data = msg.data as { batchId: string; task: NodeTestResult }; if (data.batchId === batch.batchId) handleResult(data.task); } }); } catch {}
        startPolling(batch.batchId);
      }
    } catch (err: unknown) { const msg = (err && typeof err === 'object' && 'response' in err) ? ((err as any).response?.data?.error?.message || (err as any).message) : (err instanceof Error ? err.message : ''); setError(msg || '测试失败'); setLoading(false); }
  };

  const sortedResults = Array.from(results.values()).sort((a, b) => { const aRtt = ((a.result as Record<string, unknown>)?.avgRtt as number) ?? Infinity; const bRtt = ((b.result as Record<string, unknown>)?.avgRtt as number) ?? Infinity; return aRtt - bRtt; });
  const completedCount = sortedResults.filter(r => r.status === 'completed' || r.status === 'failed').length;
  const successCount = sortedResults.filter(r => r.status === 'completed').length;
  const failedCount = sortedResults.filter(r => r.status === 'failed').length;

  const getLatencyColor = (ms: number) => { if (ms < 50) return 'success.main'; if (ms < 100) return 'success.light'; if (ms < 200) return 'warning.main'; if (ms < 500) return 'warning.dark'; return 'error.main'; };
  const getPacketLossColor = (loss: number) => { if (loss === 0) return 'success.main'; if (loss < 5) return 'warning.main'; if (loss < 20) return 'warning.dark'; return 'error.main'; };

  const theme = useTheme();
  const isMobile = !useMediaQuery(theme.breakpoints.up('sm'));

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" fontWeight={700}>Ping 多点测速</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>从全球多个节点同时 Ping 目标主机，检测各地网络连通性</Typography>
      </Box>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>Ping 测试</Typography>
          <Grid container spacing={2} alignItems="flex-end">
            <Grid item xs={12} sm={5}>
              <TextField
                fullWidth size="small"
                label="目标地址"
                placeholder="域名或 IP 地址，如: baidu.com"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleTest()}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth size="small" select label="测试次数" value={count}
                onChange={(e) => setCount(Number(e.target.value))}
                SelectProps={{ native: true }}
              >
                {[4, 10, 20, 50].map(n => <option key={n} value={n}>{n}</option>)}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={3}>
              <Button variant="contained" fullWidth startIcon={<WifiTetheringIcon />} onClick={handleTest} disabled={loading || !target.trim()}>
                {loading ? '测试中...' : '开始 Ping'}
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}

      {batchId && (
        <>
          <Grid container spacing={2} sx={{ mb: 3 }}>
            {[
              { label: '测试节点', value: totalNodes, color: 'primary' },
              { label: '已完成', value: `${completedCount}/${totalNodes}`, color: 'info' },
              { label: '成功', value: successCount, color: 'success' },
              { label: '失败', value: failedCount, color: 'error' },
            ].map((s) => (
              <Grid item xs={6} md={3} key={s.label}>
                <Card><CardContent sx={{ textAlign: 'center', py: 2 }}><Typography variant="h5" fontWeight={700} color={`${s.color}.main`}>{s.value}</Typography><Typography variant="caption" color="text.secondary">{s.label}</Typography></CardContent></Card>
              </Grid>
            ))}
          </Grid>

          {loading && <Box sx={{ mb: 3 }}><LinearProgress variant="determinate" value={totalNodes > 0 ? (completedCount / totalNodes) * 100 : 0} /><Typography variant="caption" color="text.secondary" sx={{ display: 'block', textAlign: 'center', mt: 0.5 }}>正在测试... {completedCount}/{totalNodes} 节点已完成</Typography></Box>}

          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                <Typography variant="h6" fontWeight={600}>测试结果</Typography>
                <Typography variant="caption" color="text.secondary">按延迟排序</Typography>
              </Box>

              {isMobile ? (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                  {sortedResults.map((task) => {
                    const r = task.result as Record<string, unknown> | undefined;
                    const isRunning = task.status === 'running' || task.status === 'pending';
                    const avgRtt = (r?.avgRtt as number) || 0;
                    const packetLoss = (r?.packetLoss as number) || 0;
                    const packetsSent = (r?.packetsSent as number) || 0;
                    const packetsReceived = (r?.packetsReceived as number) || 0;
                    const resolvedIp = r?.resolvedIp as string | undefined;
                    const targetLoc = r?.targetLocation as Record<string, string> | undefined;
                    return (
                      <Card key={task.taskId} variant="outlined" sx={isRunning ? { bgcolor: 'warning.50' } : task.status === 'failed' ? { bgcolor: 'error.50' } : {}}>
                        <CardContent sx={{ py: 1.5, '&:last-child': { pb: 1.5 } }}>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                            <Typography variant="body2" fontWeight={600}>{task.nodeName}</Typography>
                            {isRunning && <Chip label="测试中" size="small" color="warning" />}
                            {task.status === 'completed' && <Chip label="正常" size="small" color="success" />}
                            {task.status === 'failed' && <Chip label="失败" size="small" color="error" />}
                          </Box>
                          <Typography variant="caption" color="text.secondary">{task.nodeLocation}</Typography>
                          {resolvedIp && <Typography variant="caption" sx={{ fontFamily: 'monospace', color: 'info.main', display: 'block', mt: 0.25 }}>{resolvedIp}</Typography>}
                          {targetLoc && (
                            <Typography variant="caption" sx={{ display: 'block', color: 'secondary.main', mt: 0.1 }}>
                              {targetLoc.country} {targetLoc.region} {targetLoc.city}{targetLoc.isp ? ` ${targetLoc.isp}` : ''}
                            </Typography>
                          )}
                          <Grid container spacing={1} sx={{ mt: 0.5 }}>
                            {[
                              { label: '平均', value: `${avgRtt.toFixed(1)}ms`, color: getLatencyColor(avgRtt) },
                              { label: '丢包', value: `${packetLoss.toFixed(1)}%`, color: getPacketLossColor(packetLoss) },
                              { label: '发送/接收', value: `${packetsSent}/${packetsReceived}`, color: 'text.primary' },
                            ].map((m) => (
                              <Grid item xs={4} key={m.label}>
                                <Typography variant="caption" color="text.secondary">{m.label}</Typography>
                                <Typography variant="body2" fontWeight={600} sx={{ fontFamily: 'monospace', color: m.color }}>{m.value}</Typography>
                              </Grid>
                            ))}
                          </Grid>
                        </CardContent>
                      </Card>
                    );
                  })}
                </Box>
              ) : (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>节点</TableCell><TableCell>位置</TableCell><TableCell align="center">解析IP</TableCell><TableCell align="left">目标归属地</TableCell><TableCell align="center">状态</TableCell>
                        <TableCell align="right">最小延迟</TableCell><TableCell align="right">平均延迟</TableCell><TableCell align="right">最大延迟</TableCell>
                        <TableCell align="right">丢包率</TableCell><TableCell align="right">发送/接收</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {sortedResults.map((task) => {
                        const r = task.result as Record<string, unknown> | undefined;
                        const isRunning = task.status === 'running' || task.status === 'pending';
                        const minRtt = (r?.minRtt as number) || 0;
                        const avgRtt = (r?.avgRtt as number) || 0;
                        const maxRtt = (r?.maxRtt as number) || 0;
                        const packetLoss = (r?.packetLoss as number) || 0;
                        const packetsSent = (r?.packetsSent as number) || 0;
                        const packetsReceived = (r?.packetsReceived as number) || 0;
                        const resolvedIp = r?.resolvedIp as string | undefined;
                        const targetLoc = r?.targetLocation as Record<string, string> | undefined;
                        return (
                          <TableRow key={task.taskId} sx={isRunning ? { bgcolor: 'warning.50' } : task.status === 'failed' ? { bgcolor: 'error.50' } : {}}>
                            <TableCell sx={{ fontWeight: 600 }}>{task.nodeName}</TableCell>
                            <TableCell>{task.nodeLocation}</TableCell>
                            <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.75rem', color: 'info.main' }}>{resolvedIp || '-'}</TableCell>
                            <TableCell sx={{ fontSize: '0.72rem' }}>
                              {targetLoc ? `${targetLoc.country} ${targetLoc.region} ${targetLoc.city}${targetLoc.isp ? ` ${targetLoc.isp}` : ''}` : '-'}
                            </TableCell>
                            <TableCell align="center">
                              {isRunning && <Chip label="测试中" size="small" color="warning" />}
                              {task.status === 'completed' && <Chip label="正常" size="small" color="success" />}
                              {task.status === 'failed' && <Chip label="失败" size="small" color="error" />}
                            </TableCell>
                            <TableCell align="right" sx={{ fontFamily: 'monospace', color: getLatencyColor(minRtt) }}>{minRtt.toFixed(1)}ms</TableCell>
                            <TableCell align="right" sx={{ fontFamily: 'monospace', fontWeight: 700, color: getLatencyColor(avgRtt) }}>{avgRtt.toFixed(1)}ms</TableCell>
                            <TableCell align="right" sx={{ fontFamily: 'monospace', color: getLatencyColor(maxRtt) }}>{maxRtt.toFixed(1)}ms</TableCell>
                            <TableCell align="right" sx={{ fontFamily: 'monospace', color: getPacketLossColor(packetLoss) }}>{packetLoss.toFixed(1)}%</TableCell>
                            <TableCell align="right" color="text.secondary">{`${packetsSent}/${packetsReceived}`}</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}

              {sortedResults.length === 0 && loading && <Box sx={{ textAlign: 'center', py: 4 }}><Typography color="text.secondary">正在分配测试任务到各节点...</Typography></Box>}
            </CardContent>
          </Card>
        </>
      )}
    </Box>
  );
}
