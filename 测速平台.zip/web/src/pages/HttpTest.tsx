import { useState, useEffect, useRef, useCallback } from 'react';
import { testApi, createTestWebSocket, NodeTestResult } from '../api';
import {
  Box, Typography, Card, CardContent, Grid, TextField, Button,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Chip, LinearProgress, Alert, Paper, Collapse, IconButton, useMediaQuery, useTheme, MenuItem,
} from '@mui/material';
import LanguageIcon from '@mui/icons-material/Language';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import CodeIcon from '@mui/icons-material/Code';

export function HttpTest() {
  const [url, setUrl] = useState('');
  const [method, setMethod] = useState('GET');
  const [headers, setHeaders] = useState('');
  const [body, setBody] = useState('');
  const [timeout, setTimeout_] = useState(10000);
  const [loading, setLoading] = useState(false);
  const [batchId, setBatchId] = useState<string | null>(null);
  const [results, setResults] = useState<Map<string, NodeTestResult>>(new Map());
  const [totalNodes, setTotalNodes] = useState(0);
  const [error, setError] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const wsRef = useRef<WebSocket | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const toggleRow = useCallback((taskId: string) => {
    setExpandedRows(prev => {
      const next = new Set(prev);
      if (next.has(taskId)) next.delete(taskId); else next.add(taskId);
      return next;
    });
  }, []);

  const handleResult = useCallback((taskResult: NodeTestResult) => {
    setResults(prev => { const next = new Map(prev); next.set(taskResult.taskId, taskResult); return next; });
  }, []);

  useEffect(() => { return () => { wsRef.current?.close(); if (pollRef.current) clearInterval(pollRef.current); }; }, []);

  const startPolling = (id: string) => {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const res = await testApi.getBatch(id);
        if (res.data.success && res.data.data) { const batch = res.data.data; for (const task of batch.tasks) handleResult(task); if (['completed', 'partial', 'failed'].includes(batch.status)) { if (pollRef.current) clearInterval(pollRef.current); setLoading(false); } }
      } catch {}
    }, 2000);
  };

  const handleTest = async () => {
    if (!url.trim()) { setError('请输入URL'); return; }
    setLoading(true); setError(''); setResults(new Map()); setBatchId(null); setExpandedRows(new Set());
    try {
      let parsedHeaders: Record<string, string> | undefined;
      if (headers.trim()) parsedHeaders = JSON.parse(headers);
      const response = await testApi.http({ url: url.trim(), method, headers: parsedHeaders, body: body || undefined, timeout, followRedirects: true, validateCert: true, maxNodes: 50 });
      if (response.data.success && response.data.data) {
        const batch = response.data.data;
        setBatchId(batch.batchId); setTotalNodes(batch.totalNodes);
        try { wsRef.current?.close(); wsRef.current = createTestWebSocket((msg) => { if (msg.type === 'test:result' && msg.data) { const data = msg.data as { batchId: string; task: NodeTestResult }; if (data.batchId === batch.batchId) handleResult(data.task); } }); } catch {}
        startPolling(batch.batchId);
      }
    } catch (err: unknown) { const axiosErr = err as { response?: { data?: { error?: { message?: string } } }; message?: string }; setError(axiosErr.response?.data?.error?.message || axiosErr.message || '测试失败'); setLoading(false); }
  };

  const sortedResults = Array.from(results.values()).sort((a, b) => { const aTime = (a.result as Record<string, number>)?.responseTime ?? Infinity; const bTime = (b.result as Record<string, number>)?.responseTime ?? Infinity; return aTime - bTime; });
  const completedCount = sortedResults.filter(r => r.status === 'completed' || r.status === 'failed').length;
  const successCount = sortedResults.filter(r => r.status === 'completed').length;
  const failedCount = sortedResults.filter(r => r.status === 'failed').length;

  const getResponseTimeColor = (ms: number) => { if (ms < 200) return 'success.main'; if (ms < 500) return 'info.main'; if (ms < 1000) return 'warning.main'; if (ms < 3000) return 'warning.dark'; return 'error.main'; };
  const getStatusChipColor = (code: number) => { if (code >= 200 && code < 300) return 'success'; if (code >= 300 && code < 400) return 'info'; if (code >= 400 && code < 500) return 'warning'; if (code >= 500) return 'error'; return 'default' };

  const theme = useTheme();
  const isMobile = !useMediaQuery(theme.breakpoints.up('sm'));

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h5" fontWeight={700}>HTTP 多点测速</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>从全球多个节点同时请求目标URL，检测各地HTTP响应状态</Typography>
      </Box>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="flex-end">
            <Grid item xs={12} sm={6}>
              <TextField label="URL" size="small" fullWidth value={url}
                onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleTest()}
                placeholder="https://example.com" />
            </Grid>
            <Grid item xs={6} sm={3}>
              <TextField label="方法" select size="small" value={method} onChange={(e) => setMethod(e.target.value)} fullWidth
                SelectProps={{ native: true }}>
                <option value="GET">GET</option><option value="POST">POST</option><option value="PUT">PUT</option><option value="HEAD">HEAD</option>
              </TextField>
            </Grid>
            <Grid item xs={6} sm={3}>
              <Button variant="outlined" onClick={() => setShowAdvanced(!showAdvanced)}
                startIcon={showAdvanced ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                sx={{ width: '100%', height: '100%' }}>{showAdvanced ? '收起' : '高级'}</Button>
            </Grid>
          </Grid>
          <Box sx={{ mt: 1 }}>
            <Button variant="contained" startIcon={<LanguageIcon />} disabled={loading} onClick={handleTest} fullWidth>{loading ? '测试中...' : '开始测试'}</Button>
          </Box>
          <Collapse in={showAdvanced}>
            <Grid container spacing={2} sx={{ mt: 2, pt: 2, borderTop: 1, borderColor: 'divider' }}>
              <Grid item xs={12} md={4}><TextField label="请求头 (JSON)" size="small" multiline rows={2} value={headers} onChange={(e) => setHeaders(e.target.value)} placeholder='{"Authorization": "Bearer token"}' fullWidth /></Grid>
              <Grid item xs={12} md={4}><TextField label="请求体" size="small" multiline rows={2} value={body} onChange={(e) => setBody(e.target.value)} placeholder='{"key": "value"}' fullWidth /></Grid>
              <Grid item xs={12} md={4}><TextField label="超时(ms)" type="number" size="small" value={timeout} onChange={(e) => setTimeout_(parseInt(e.target.value) || 10000)} fullWidth /></Grid>
            </Grid>
          </Collapse>
        </CardContent>
      </Card>

      {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}

      {batchId && (
        <>
          <Grid container spacing={2} sx={{ mb: 3 }}>
            {[
              { label: '测试节点', value: totalNodes, color: 'primary' },
              { label: '已完成', value: `${completedCount}/${totalNodes}`, color: 'info' },
              { label: '成功', value: successCount, color: 'success' },
              { label: '失败', value: failedCount, color: 'error' },
            ].map((s) => (
              <Grid item xs={6} md={3} key={s.label}>
                <Card><CardContent sx={{ textAlign: 'center', py: 2 }}><Typography variant="h5" fontWeight={700} color={`${s.color}.main`}>{s.value}</Typography><Typography variant="caption" color="text.secondary">{s.label}</Typography></CardContent></Card>
              </Grid>
            ))}
          </Grid>

          {loading && <Box sx={{ mb: 3 }}><LinearProgress variant="determinate" value={totalNodes > 0 ? (completedCount / totalNodes) * 100 : 0} /><Typography variant="caption" color="text.secondary" sx={{ display: 'block', textAlign: 'center', mt: 0.5 }}>正在测试... {completedCount}/{totalNodes} 节点已完成</Typography></Box>}

          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                <Typography variant="h6" fontWeight={600}>测试结果</Typography>
                <Typography variant="caption" color="text.secondary">按响应时间排序</Typography>
              </Box>

              {isMobile ? (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                  {sortedResults.map((task) => {
                    const r = task.result as Record<string, unknown> | undefined;
                    const isRunning = task.status === 'running' || task.status === 'pending';
                    const statusCode = (r?.statusCode as number) || 0;
                    const resolvedIp = r?.resolvedIp as string | undefined;
                    const responseHeaders = r?.headers as Record<string, string> | undefined;
                    const targetLoc = r?.targetLocation as Record<string, string> | undefined;
                    const responseTime = (r?.responseTime as number) || 0;
                    const ttfb = (r?.ttfb as number) || 0;
                    const downloadSize = (r?.downloadSize as number) || 0;
                    const expanded = expandedRows.has(task.taskId);
                    return (
                      <Card key={task.taskId} variant="outlined"
                        sx={isRunning ? { bgcolor: 'warning.50' } : task.status === 'failed' ? { bgcolor: 'error.50' } : {}}>
                        <CardContent sx={{ py: 1.5, '&:last-child': { pb: 1.5 } }}>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
                            <Typography variant="body2" fontWeight={600}>{task.nodeName}</Typography>
                            {isRunning && <Chip label="..." size="small" color="warning" />}
                            {task.status === 'completed' && <Chip label={statusCode} size="small" color={getStatusChipColor(statusCode)} />}
                            {task.status === 'failed' && <Chip label="失败" size="small" color="error" />}
                          </Box>
                          <Typography variant="caption" color="text.secondary">{task.nodeLocation}</Typography>
                          {resolvedIp && <Typography variant="caption" sx={{ fontFamily: 'monospace', color: 'info.main', display: 'block', mt: 0.25 }}>{resolvedIp}</Typography>}
                          {targetLoc && (
                            <Typography variant="caption" sx={{ display: 'block', color: 'secondary.main', mt: 0.1 }}>
                              {targetLoc.country} {targetLoc.region} {targetLoc.city}{targetLoc.isp ? ` ${targetLoc.isp}` : ''}
                            </Typography>
                          )}
                          <Grid container spacing={1} sx={{ mt: 0.5 }}>
                            {[
                              { label: '总耗时', value: `${responseTime.toFixed(0)}ms`, color: getResponseTimeColor(responseTime) },
                              { label: 'TTFB', value: `${ttfb.toFixed(0)}ms` },
                              { label: '大小', value: downloadSize ? `${(downloadSize / 1024).toFixed(1)}KB` : '-' },
                            ].map((m) => (
                              <Grid item xs={4} key={m.label}>
                                <Typography variant="caption" color="text.secondary">{m.label}</Typography>
                                <Typography variant="body2" fontWeight={600} sx={{ fontFamily: 'monospace', color: m.color }}>{m.value}</Typography>
                              </Grid>
                            ))}
                          </Grid>
                          {task.status === 'completed' && responseHeaders && Object.keys(responseHeaders).length > 0 && (
                            <>
                              <Button size="small" startIcon={<CodeIcon />} onClick={() => toggleRow(task.taskId)} sx={{ mt: 0.75, fontSize: '0.7rem' }}>
                                {expanded ? '收起响应头' : `查看响应头 (${Object.keys(responseHeaders).length})`}
                              </Button>
                              <Collapse in={expanded}>
                                <Paper variant="outlined" sx={{ p: 1, mt: 0.5, bgcolor: 'grey.900', maxHeight: 200, overflow: 'auto' }}>
                                  {Object.entries(responseHeaders).map(([key, val]) => (
                                    <Box key={key} sx={{ mb: 0.3 }}>
                                      <Typography component="span" sx={{ fontFamily: 'monospace', fontSize: '0.68rem', color: 'success.light', mr: 0.5 }}>{key}:</Typography>
                                      <Typography component="span" sx={{ fontFamily: 'monospace', fontSize: '0.68rem', color: 'grey.300', wordBreak: 'break-all' }}>{val}</Typography>
                                    </Box>
                                  ))}
                                </Paper>
                              </Collapse>
                            </>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </Box>
              ) : (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>节点</TableCell><TableCell>位置</TableCell><TableCell align="center">解析IP</TableCell><TableCell align="left">目标归属地</TableCell><TableCell align="center">状态码</TableCell>
                        <TableCell align="right">总耗时</TableCell><TableCell align="right">TTFB</TableCell><TableCell align="right">DNS</TableCell><TableCell align="right">大小</TableCell>
                        <TableCell />
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {sortedResults.map((task) => {
                        const r = task.result as Record<string, unknown> | undefined;
                        const isRunning = task.status === 'running' || task.status === 'pending';
                        const statusCode = (r?.statusCode as number) || 0;
                        const resolvedIp = r?.resolvedIp as string | undefined;
                        const responseHeaders = r?.headers as Record<string, string> | undefined;
                        const targetLoc = r?.targetLocation as Record<string, string> | undefined;
                        const responseTime = (r?.responseTime as number) || 0;
                        const ttfb = (r?.ttfb as number) || 0;
                        const dnsTime = (r?.dnsTime as number) || 0;
                        const downloadSize = (r?.downloadSize as number) || 0;
                        const expanded = expandedRows.has(task.taskId);
                        return (
                          <>
                            <TableRow key={task.taskId} sx={isRunning ? { bgcolor: 'warning.50' } : task.status === 'failed' ? { bgcolor: 'error.50' } : {}}>
                              <TableCell sx={{ fontWeight: 600 }}>{task.nodeName}</TableCell>
                              <TableCell>{task.nodeLocation}</TableCell>
                              <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.75rem', color: 'info.main' }}>{resolvedIp || '-'}</TableCell>
                              <TableCell sx={{ fontSize: '0.72rem' }}>
                                {targetLoc ? `${targetLoc.country} ${targetLoc.region} ${targetLoc.city}${targetLoc.isp ? ` ${targetLoc.isp}` : ''}` : '-'}
                              </TableCell>
                              <TableCell align="center">
                                {isRunning && <Chip label="..." size="small" color="warning" />}
                                {task.status === 'completed' && <Chip label={statusCode} size="small" color={getStatusChipColor(statusCode)} />}
                                {task.status === 'failed' && <Chip label="失败" size="small" color="error" />}
                              </TableCell>
                              <TableCell align="right" sx={{ fontFamily: 'monospace', fontWeight: 700, color: getResponseTimeColor(responseTime) }}>{responseTime.toFixed(0)}ms</TableCell>
                              <TableCell align="right" sx={{ fontFamily: 'monospace', color: 'text.secondary' }}>{ttfb.toFixed(0)}ms</TableCell>
                              <TableCell align="right" sx={{ fontFamily: 'monospace', color: 'text.secondary' }}>{dnsTime.toFixed(0)}ms</TableCell>
                              <TableCell align="right" color="text.secondary">{downloadSize ? `${(downloadSize / 1024).toFixed(1)}KB` : '-'}</TableCell>
                              <TableCell align="center">
                                {task.status === 'completed' && responseHeaders && Object.keys(responseHeaders).length > 0 && (
                                  <IconButton size="small" onClick={() => toggleRow(task.taskId)}>
                                    <CodeIcon fontSize="small" />
                                  </IconButton>
                                )}
                              </TableCell>
                            </TableRow>
                            {expanded && responseHeaders && (
                              <TableRow>
                                <TableCell colSpan={10} sx={{ p: 0 }}>
                                  <Collapse in={expanded}>
                                    <Paper variant="outlined" sx={{ mx: 2, my: 0.5, p: 1.5, bgcolor: 'grey.900', maxHeight: 250, overflow: 'auto' }}>
                                      <Typography variant="caption" color="text.secondary" sx={{ mb: 0.5, display: 'block' }}>HTTP 响应头 ({Object.keys(responseHeaders).length} 条)</Typography>
                                      {Object.entries(responseHeaders).map(([key, val]) => (
                                        <Box key={key} sx={{ mb: 0.3, pl: 1 }}>
                                          <Typography component="span" sx={{ fontFamily: 'monospace', fontSize: '0.72rem', color: 'success.light', mr: 1 }}>{key}:</Typography>
                                          <Typography component="span" sx={{ fontFamily: 'monospace', fontSize: '0.72rem', color: 'grey.300', wordBreak: 'break-all' }}>{val}</Typography>
                                        </Box>
                                      ))}
                                    </Paper>
                                  </Collapse>
                                </TableCell>
                              </TableRow>
                            )}
                          </>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
              {sortedResults.length === 0 && loading && <Box sx={{ textAlign: 'center', py: 4 }}><Typography color="text.secondary">正在分配测试任务到各节点...</Typography></Box>}
            </CardContent>
          </Card>
        </>
      )}
    </Box>
  );
}
