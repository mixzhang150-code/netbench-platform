import { useState } from 'react';
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom';
import {
  Box, Drawer, List, ListItemButton, ListItemIcon, ListItemText,
  Typography, Avatar, Button, Divider, AppBar, Toolbar, IconButton,
  useMediaQuery, useTheme,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import DashboardIcon from '@mui/icons-material/Dashboard';
import WifiTetheringIcon from '@mui/icons-material/WifiTethering';
import LanguageIcon from '@mui/icons-material/Language';
import SpeedIcon from '@mui/icons-material/Speed';
import DnsIcon from '@mui/icons-material/Dns';
import HistoryIcon from '@mui/icons-material/History';
import SettingsIcon from '@mui/icons-material/Settings';
import PersonIcon from '@mui/icons-material/Person';
import PeopleIcon from '@mui/icons-material/People';
import LoginIcon from '@mui/icons-material/Login';
import LogoutIcon from '@mui/icons-material/Logout';
import DownloadIcon from '@mui/icons-material/Download';
import { useAuthStore } from '../store/auth';

const DRAWER_WIDTH = 260;

const publicNavItems = [
  { path: '/', label: '仪表盘', icon: <DashboardIcon /> },
  { path: '/ping', label: 'Ping测试', icon: <WifiTetheringIcon /> },
  { path: '/http', label: 'HTTP测试', icon: <LanguageIcon /> },
  { path: '/speedtest', label: '网络测速', icon: <SpeedIcon /> },
  { path: '/history', label: '历史记录', icon: <HistoryIcon /> },
  { path: '/sponsor', label: '节点赞助', icon: <DownloadIcon /> },
];

const adminSubNavItems = [
  { path: '/admin', label: '概览', icon: <SettingsIcon /> },
  { path: '/admin/nodes', label: '节点管理', icon: <DnsIcon /> },
  { path: '/admin/users', label: '用户管理', icon: <PeopleIcon /> },
];

function NavContent({ onNavigate }: { onNavigate?: () => void }) {
  const location = useLocation();
  const { user, isAuthenticated, logout } = useAuthStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
    onNavigate?.();
  };

  return (
    <>
      <Box sx={{ p: 2.5, borderBottom: 1, borderColor: 'divider' }}>
        <Typography variant="h6" fontWeight={700} color="primary">
          NetBench
        </Typography>
        <Typography variant="caption" color="text.secondary">
          网络测试平台
        </Typography>
      </Box>

      <List sx={{ flex: 1, px: 1, py: 1 }}>
        {publicNavItems.map((item) => (
          <ListItemButton
            key={item.path}
            component={NavLink}
            to={item.path}
            selected={item.path === '/' ? location.pathname === '/' : location.pathname.startsWith(item.path)}
            sx={{ borderRadius: 1, mb: 0.5 }}
            onClick={() => onNavigate?.()}
          >
            <ListItemIcon sx={{ minWidth: 40 }}>{item.icon}</ListItemIcon>
            <ListItemText primary={item.label} primaryTypographyProps={{ fontSize: 14 }} />
          </ListItemButton>
        ))}

        {isAuthenticated && user?.role === 'admin' && (
          <>
            <Divider sx={{ my: 1.5 }} />
            <Typography variant="caption" color="text.secondary" sx={{ px: 1.5, mb: 0.5, display: 'block' }}>管理</Typography>
            {adminSubNavItems.map((item) => (
              <ListItemButton
                key={item.path}
                component={NavLink}
                to={item.path}
                selected={item.path === '/admin'
                  ? location.pathname === '/admin'
                  : location.pathname.startsWith(item.path)}
                sx={{ borderRadius: 1, mb: 0.3 }}
                onClick={() => onNavigate?.()}
              >
                <ListItemIcon sx={{ minWidth: 40 }}>{item.icon}</ListItemIcon>
                <ListItemText primary={item.label} primaryTypographyProps={{ fontSize: 14 }} />
              </ListItemButton>
            ))}
          </>
        )}
      </List>

      <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
        {isAuthenticated ? (
          <>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
              <Avatar sx={{ width: 32, height: 32, bgcolor: 'primary.light', fontSize: 14, fontWeight: 700 }}>
                {user?.username?.charAt(0).toUpperCase()}
              </Avatar>
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography variant="body2" fontWeight={600} noWrap>{user?.username}</Typography>
                <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'capitalize' }}>{user?.role}</Typography>
              </Box>
            </Box>
            <Button
              fullWidth
              size="small"
              startIcon={<PersonIcon />}
              onClick={() => { navigate('/profile'); onNavigate?.(); }}
              color="inherit"
              sx={{ justifyContent: 'flex-start', color: 'text.secondary', mb: 0.5 }}
            >
              个人设置
            </Button>
            <Button
              fullWidth
              size="small"
              startIcon={<LogoutIcon />}
              onClick={handleLogout}
              color="inherit"
              sx={{ justifyContent: 'flex-start', color: 'text.secondary' }}
            >
              退出登录
            </Button>
          </>
        ) : (
          <Button
            fullWidth
            variant="contained"
            startIcon={<LoginIcon />}
            onClick={() => navigate('/login')}
          >
            登录
          </Button>
        )}
      </Box>
    </>
  );
}

export function Layout() {
  const theme = useTheme();
  const isMobile = !useMediaQuery(theme.breakpoints.up('md'));
  const [drawerOpen, setDrawerOpen] = useState(false);

  if (isMobile) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        <AppBar position="sticky" elevation={0} sx={{ bgcolor: 'background.paper', borderBottom: 1, borderColor: 'divider' }}>
          <Toolbar sx={{ justifyContent: 'space-between', minHeight: { xs: 56, sm: 64 }, px: 1 }}>
            <IconButton edge="start" onClick={() => setDrawerOpen(true)} size="small">
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" fontWeight={700} color="primary">NetBench</Typography>
            <Box sx={{ width: 36 }} />
          </Toolbar>
        </AppBar>

        <Drawer
          variant="temporary"
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          ModalProps={{ keepMounted: true }}
          sx={{
            '& .MuiDrawer-paper': { width: DRAWER_WIDTH, boxSizing: 'border-box' },
          }}
        >
          <NavContent onNavigate={() => setDrawerOpen(false)} />
        </Drawer>

        <Box component="main" sx={{ flex: 1, overflow: 'auto', bgcolor: 'grey.50' }}>
          <Box sx={{ p: 2 }}>
            <Outlet />
          </Box>
        </Box>
      </Box>
    );
  }

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <Drawer
        variant="permanent"
        sx={{
          width: DRAWER_WIDTH,
          flexShrink: 0,
          '& .MuiDrawer-paper': { width: DRAWER_WIDTH, boxSizing: 'border-box' },
        }}
      >
        <NavContent />
      </Drawer>

      <Box component="main" sx={{ flex: 1, overflow: 'auto', bgcolor: 'grey.50' }}>
        <Box sx={{ maxWidth: 1200, mx: 'auto', p: 4 }}>
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
}
